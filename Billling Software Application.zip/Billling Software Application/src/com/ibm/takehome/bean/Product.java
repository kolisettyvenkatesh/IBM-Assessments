package com.ibm.takehome.bean;

public class Product {

	private int productid;
	private String productname;
	private String productcategory;
	private int productprice;
	
	public Product(int productid, String productname, String productcategory, int productprice)
	{
		 this.productid = productid;
		 this.productname = productname;
		 this.productcategory = productcategory;
		 this.productprice = productprice;
	}
	
	public int getproductId() {
		return productid;
	}

	public void setproductId(int productid) {
		this.productid = productid;
	}

	public String getproductName() {
		return productname;
	}

	public void setproductName(String productname) {
		this.productname = productname;
	}

	public String getproductCategory() {
		return productcategory;
	}

	public void setproductCategory(String productcategory) {
		this.productcategory = productcategory;
	}

	public int getproductPrice() {
		return productprice;
	}

	public void setproductPrice(int productprice) {
		this.productprice = productprice;
	}

	@Override
	public String toString() {
		return "Product [productname=" + productname + ", id=" + productid + ",productcategory=" + productcategory + ",productprice=" + productprice + "]";
	}

	public static void put(int i, Product product) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
}
