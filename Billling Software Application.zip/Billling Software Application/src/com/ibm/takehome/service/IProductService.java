package com.ibm.takehome.service;

import java.util.Map;

import com.ibm.takehome.bean.Product;

public interface IProductService {

	void storeIntoMap(Product product);

	Map<Integer, Product> displayProduct();

	boolean checkTotal(int productprice, int quantity);

}
