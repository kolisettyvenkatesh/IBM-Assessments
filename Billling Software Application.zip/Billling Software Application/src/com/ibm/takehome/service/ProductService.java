package com.ibm.takehome.service;

import com.ibm.takehome.bean.Product;
import com.ibm.takehome.dao.IProductDAO;
import com.ibm.takehome.dao.ProductDAO;
import java.util.Map;


public class ProductService implements IProductService {

	IProductDAO dao = new ProductDAO();


	@Override
	public void storeIntoMap(Product product) {
		
		
		dao.storeIntoMap(product);

	}

	public Map<Integer, Product> displayProduct() {

		return dao.displayProduct();
	}

	@Override
	public boolean checkTotal(int productprice, int quantity) 
	{
		
		return true;
		
		
	}
}