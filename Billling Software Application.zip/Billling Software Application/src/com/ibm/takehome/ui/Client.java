package com.ibm.takehome.ui;

import java.util.Scanner;
import com.ibm.takehome.service.ProductService;
import com.ibm.takehome.service.IProductService;
import com.ibm.takehome.bean.*;

public class Client {

	
		public static void main(String[] args)
		{

			int productid;
			String productname;
			String productcategory;
			int productprice;
			int quantity;
	
			IProductService service = new ProductService();
			Scanner sc = new Scanner(System.in);
			
	while(true)
			{
				System.out.println("1.Enter the Product Deatils\n" );
						System.out.println("Enter Product ID");
						productid = sc.nextInt();
						sc.nextLine();
						
						
						System.out.println("enter Product name");
						productname = sc.nextLine();
						 
						System.out.println("enter Product Category ");
						productcategory = sc.nextLine();
						
						System.out.println("enter Product Price ");
						productprice = sc.nextInt();
						sc.nextLine();
						
						System.out.println("enter the quantity ");
						quantity = sc.nextInt();
						sc.nextLine();
						
						if( service.checkTotal(productprice, quantity))
						{	 
						 
						 Product product = new Product(productid, productname, productcategory, productprice);
						 product.setproductId(productid);
						 product.setproductName(productname);
						 product.setproductCategory(productcategory);
						 product.setproductPrice(productprice);
					
						 
						 service.storeIntoMap(product);
						 System.out.println(service.displayProduct());
					
						}
			}
						
		}
	
}
