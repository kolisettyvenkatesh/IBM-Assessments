package com.ibm.takehome.dao;

import java.util.Map;

import com.ibm.takehome.bean.Product;

public interface IProductDAO {

	void storeIntoMap(Product product);

	Map<Integer, Product> displayProduct();

}
