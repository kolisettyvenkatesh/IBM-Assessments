package com.ibm.takehome.dao;

import java.util.HashMap;
import java.util.Map;

import com.ibm.takehome.bean.Product;

public class ProductDAO implements IProductDAO 
{

	private Map<Integer,Product> products=new HashMap<Integer,Product>();
	
	static int i = 1001;
	
	public void storeIntoMap(Product product) {
	
		products.put(i, product);
		i++;
		
	}
	
	

	@Override
	public Map<Integer, Product> displayProduct() {
		// TODO Auto-generated method stub
		return products;
	}

	
		
	}